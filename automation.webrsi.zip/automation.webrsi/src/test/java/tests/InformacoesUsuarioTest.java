package tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import suporte.ExecutaNavegador;
import suporte.Generator;
import suporte.Screenshot;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class InformacoesUsuarioTest {
    private WebDriver driver;

    @Rule
    public TestName test = new TestName();
    @Before
    public void setUp(){
        driver = ExecutaNavegador.executaNavegador();

    }

    @Test
    public void testAcessarPortal() throws InterruptedException, IOException {

        // Clicar no campo User "//*[@id="menuUser"]"
        driver.findElement(By.id("hrefUserIcon")).click();
        // Clicar no link com o nome de "CREATE NEW ACCOUNT" que está dentro do formulario do xpath"//div[@class='login ng-scope']"
        WebElement formLogin = driver.findElement(By.xpath("//div[@class='login ng-scope']"));
        // Clicar no campo com o nome "username" que está dentro do formulario da class"//div[@class='login ng-scope']"
        formLogin.findElement(By.name("username")).sendKeys("testeautomatico");
        // Clicar no campo com o nome "password" que está dentro do formulario da class"//div[@class='login ng-scope']"
        formLogin.findElement(By.name("password")).sendKeys("teste1234");
        // Clicar no link com o nome de "CREATE NEW ACCOUNT" que está dentro do formulario da class"//div[@class='login ng-scope']"
        formLogin.findElement(By.xpath("//a[@class='create-new-account ng-scope']")).click();
        // Clicar no campo com o nome de "usernameRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("usernameRegisterPage")).sendKeys("Caiovinicius4");
        // Clicar no campo com o nome de "emailRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("emailRegisterPage")).sendKeys("caio_surfing@icloud.com");
        // Clicar no campo com o nome de "passwordRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("passwordRegisterPage")).sendKeys("Qwert123");
        // Clicar no campo com o nome de "confirm_passwordRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("confirm_passwordRegisterPage")).sendKeys("Qwert123");
        // Clicar no campo com o nome de "first_nameRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("first_nameRegisterPage")).sendKeys("Caio Surfing");
        //Clicar no campo com o nome de "last_nameRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("last_nameRegisterPage")).sendKeys("Praia");
        // Clicar no campo com o nome de "phone_numberRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("phone_numberRegisterPage")).sendKeys("11988887777");
        // Clicar no campo com o nome de "countryListboxRegisterPage" que está dentro da página de Create Account
        Select selectCountry = new Select(driver.findElement(By.name("countryListboxRegisterPage")));
        selectCountry.selectByVisibleText("Brazil");
        // Clicar no campo com o nome de "cityRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("cityRegisterPage")).sendKeys("São Paulo");
        // Clicar no campo com o nome de "addressRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("addressRegisterPage")).sendKeys("Rua: caio na Keegoo");
        // Clicar no campo com o nome de "state_/_province_/_regionRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("state_/_province_/_regionRegisterPage")).sendKeys("Teste Caio");
        // Clicar no campo com o nome de "postal_codeRegisterPage" que está dentro da página de Create Account
        driver.findElement(By.name("postal_codeRegisterPage")).sendKeys("98745-432");
        //Clicar no checkbox com name de "i_agree" que está dentro da página de Create Account
        driver.findElement(By.xpath("(//label[text()='Postal Code']/following::input)[2]")).click();
        // Clicar no botão com o id "register_btnundefined" que está dentro da página de Create Account
        driver.findElement(By.id("register_btnundefined")).click();
        Thread.sleep(5000);
        String evidencia = "C:\\Users\\user\\Desktop\\evidencia" + Generator.dataHoraParaArquivo() + test.getMethodName() + ".png";
        Screenshot.takeScreenshot(driver,evidencia);
    }

    @After
    public void tearDown(){
        driver.close();
    }
}
